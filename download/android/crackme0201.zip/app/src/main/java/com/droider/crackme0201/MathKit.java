package com.droider.crackme0201;

/**
 * Created by lenovo on 2015/5/20.
 */
public class MathKit {
    public static native int square(int num);

    static {
        System.loadLibrary("helloNDK");
    }
}