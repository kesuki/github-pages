#include <com_droider_crackme0201_MathKit.h>

JNIEXPORT jint JNICALL Java_com_droider_crackme0201_MathKit_square
  (JNIEnv *env, jclass cls, jint num)
  {
        return num*num;
  }