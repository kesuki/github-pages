package com.droider.dexunshellram;

/**
 * Created by Mak on 2015/5/27.
 */
public class unshellram {
    static native int loadDex(byte[] dex,long dexlen);

    static {
        System.loadLibrary("unshellram");
    }
}
